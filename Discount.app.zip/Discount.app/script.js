﻿let currentUser = null;
let isAdmin = false;

function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;

  if (username === 'admin' && password === 'admin') {
    currentUser = username;
    isAdmin = true;
    showAdminContainer();
  } else if (username !== 'admin' && password !== 'admin') {
    currentUser = username;
    showUserContainer();
  } else {
    alert('Invalid username or password. Try again.');
  }
}

function showUserContainer() {
  document.getElementById('loginContainer').style.display = 'none';
  document.getElementById('userContainer').style.display = 'block';
  document.getElementById('usernameDisplay').textContent = currentUser;
}

function showAdminContainer() {
  document.getElementById('loginContainer').style.display = 'none';
  document.getElementById('adminContainer').style.display = 'block';
}

function logout() {
  currentUser = null;
  isAdmin = false;
  document.getElementById('loginContainer').style.display = 'block';
  document.getElementById('userContainer').style.display = 'none';
  document.getElementById('adminContainer').style.display = 'none';
}

function showAddCategoryForm() {
  // Add logic to show the form for adding a category
}

function showAddOfferForm() {
  // Add logic to show the form for adding an offer
}
